# PX-6 人工验收清单

Run: `px6-machine-exit-20260914t164500z`  
状态：等待真实人类在可见 Chrome 中执行；本文件不构成签署。

## G1

- 前置：Runtime online and one trace-ready source saved
- 操作：从 Side Panel 依次点击打开工作台、查看来源、在工作台中打开
- 预期：同一 Workspace 被创建或聚焦，Library、Detail 与当前上下文正确且不重复 ingest
- 门槛：三个入口全部通过
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。

## G2

- 前置：Workspace 已打开
- 操作：访问五类 route 并执行 direct-open、reload、Back、reopen
- 预期：route 与稳定 ID 保持，无效 ID 回到 Source Library
- 门槛：5x4=20 cells 且恢复样本不少于 2
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。

## G3

- 前置：三个可丢弃真实 source 已准备
- 操作：逐个确认 Forget 后执行四种重开
- 预期：四面均不存在且四次 SOURCE_NOT_FOUND 后可回库
- 门槛：3x4=12 条同源有序链
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。

## G4

- 前置：机器架构审计可访问
- 操作：核对双容器、Runtime 权威和三个扫描根
- 预期：前端没有直连 data_service 或创建 Runtime 事实
- 门槛：architecture violations=0
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。

## G5

- 前置：四类故障证据可访问
- 操作：查看 Runtime offline、Adapter blocked、DS unreachable、source failed/degraded
- 预期：四类状态及下一步动作明确且不显示假成功
- 门槛：4/4 fault classes
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。

## G6

- 前置：可见 Chrome 与四种视口可用
- 操作：在 360/420 Side Panel 与 768/1280 Workspace 操作 drawer、dialog、键盘与 Escape
- 预期：无遮挡截断或横滚阻塞，焦点可见并返回
- 门槛：Axe serious/critical=0/0，Keyboard=5/5
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。

## G7

- 前置：A01..A14 machine audit passed
- 操作：从 EvidenceIndex 抽查 hash、截图、日志和声明
- 预期：引用可访问，声明仅限 dual-container real-Chrome acceptance
- 门槛：所有抽样引用通过且无越界声明
- 结果：由人类填写 passed/failed、notes 与 ArtifactRef。
